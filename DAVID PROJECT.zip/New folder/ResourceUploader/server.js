// server.js
const express = require('express');
const multer = require('multer');
const db = require('./database');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.static('public'));
app.use(express.json());

// Configure Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// Route to upload a new resource
app.post('/upload', upload.single('file'), (req, res) => {
  const { title } = req.body;
  const file_path = req.file ? req.file.path : null;
  const upload_date = new Date().toISOString().split('T')[0];

  if (title && file_path) {
    db.run(`INSERT INTO resources (title, file_path, upload_date) VALUES (?, ?, ?)`, 
      [title, file_path, upload_date], 
      (err) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        res.json({ success: true, message: 'File uploaded successfully' });
      }
    );
  } else {
    res.status(400).json({ error: 'Title or file missing' });
  }
});

// Route to get all resources
app.get('/resources', (req, res) => {
  db.all(`SELECT * FROM resources`, (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

// Route to delete a resource
app.delete('/resources/:id', (req, res) => {
  const { id } = req.params;
  db.run(`DELETE FROM resources WHERE id = ?`, id, (err) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ success: true, message: 'Resource deleted' });
  });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
