// database.js
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./resources.db');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS resources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      file_path TEXT NOT NULL,
      upload_date TEXT NOT NULL
  )`);
});

module.exports = db;
